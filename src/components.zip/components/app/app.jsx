import React from "react";
import appStyles from "../app/app.module.css";
import AppHeader from "../AppHeader/AppHeader";
import BurgerConstructor from "../BurgerConstructor/BurgerConstructor";
import BurgerIngredients from "../BurgerIngredients/BurgerIngredients";
import IngredientDetails from "../IngredientDetails/IngredientDetails";
import Modal from "../Modal/Modal";
import OrderDetails from "../OrderDetails/OrderDetails";
import { getIngredients  } from "../../utils/burger-api.js";

function App() {
  const [ingredients, setIngredients] = React.useState([]);
  const [isLoading, setLoading] = React.useState(true);

  const [isIngredientDetailsOpen, setIngredientDetailsOpen] = React.useState(false);
  const [isOrderDetailsOpen, setOrderDetailsOpen] = React.useState(false);
  const [selectedIngredient, setSelectedIngredient] = React.useState(null);

  const closeIngredientDetails = () => {
    setIngredientDetailsOpen(false);
  };

  const openIngredientDetails = () => {
    setIngredientDetailsOpen(true);
  };

  const closeOrderDetails = () => {
    setOrderDetailsOpen(false);
  };

  const openOrderDetails = () => {
    setOrderDetailsOpen(true);
  };

  const openModal = (clicked) => {
    setSelectedIngredient(clicked);
    if (clicked.type === "bun" || clicked.type === "sauce" || clicked.type === "main") {
      openIngredientDetails();
    } else {
      openOrderDetails();
    }
  };

  React.useEffect(() => {
    const fetchIngredients = async () => {
      setLoading(true);
      try {
        const ingredients = await getIngredients();
        setIngredients(ingredients.data);
      } catch (err) {
        console.log(err);
      } finally {
        setLoading(false);
      }
    };
    fetchIngredients();
  }, []);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <> 
      <AppHeader />
      <section className={`${appStyles.body}`}>
        <BurgerIngredients ingredients={ingredients} onIngredientClick={openModal} />
        <BurgerConstructor ingredients={ingredients} onSubmitClick={openModal} />
      </section>
      {isIngredientDetailsOpen && selectedIngredient && (
        <Modal closeModal={closeIngredientDetails}>
          <IngredientDetails
            ingredientName={selectedIngredient.name}
            calories={selectedIngredient.calories}
            proteins={selectedIngredient.proteins}
            fats={selectedIngredient.fat}
            carbs={selectedIngredient.carbohydrates}
            imageLarge={selectedIngredient.image_large}
            closePopup={closeIngredientDetails}
          />
        </Modal>
      )}
      {isOrderDetailsOpen && (
        <Modal closeModal={closeOrderDetails}>
          <OrderDetails closePopup={closeOrderDetails} />
        </Modal>
      )}
    </>
  );
}

export default App;
